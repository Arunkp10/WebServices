testagent.uninstall_application({flag = 'false'})
testagent.install_application({flag = 'false'})
testagent.start_rho_test_harness ({start = 'http://localhost:7010/runner.html'})