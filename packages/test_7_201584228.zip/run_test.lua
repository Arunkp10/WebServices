testagent.uninstall_application()
testagent.install_application()
testagent.start_rho_test_harness ({start = 'http://localhost:7010/runner.html'})